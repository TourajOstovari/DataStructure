#include <stdio.h>
#include <stdlib.h>
#include <math.h>
float jam(float adads[2])
{
    return adads[0] + adads[1];
}
float menha(float menhas[2])
{
    return menhas[0] - menhas[1];
}
float zarb(float zarbs[2])
{
    return zarbs[0] * zarbs[1];
}
float tagsim(float tagsims[2])
{
    return fmod(tagsims[0],tagsims[1]);
}
int main()
{
    printf("Salam, lotfan 2 adad vared konid \n");
    float adad[2] = {0.0 , 0.0};
    for(int x=0; x < 2; x++)
    {
        printf("adade %d \n", x);
        scanf("%f",&adad[x]);
    }
    printf("\nJam %.3f\n",jam(&adad));
    printf("Menha %.3f \n", menha(&adad));
    printf("Zarb %.3f \n", zarb(&adad));
    printf("Tagsim %.3f \n", tagsim(&adad));
    return 0;
}

// x / 2 khareje gesmat

// x % 2 bagi mande
