#include <stdio.h>
#include <stdlib.h>
int sum(int n)
{
    if(n == 0 || n == 1)
    {
        return n;
    }
    else
    {
        return sum(n-1) + sum(n-2);
    }
}
int main ()
{
	int n;
	printf("Enter Number: ");
	scanf("%d",&n);
	printf("\n%d",sum(n));
	getch();
	return 0;
}

