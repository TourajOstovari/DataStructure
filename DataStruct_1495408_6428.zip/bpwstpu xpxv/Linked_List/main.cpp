#include <iostream>
#include <string.h>
using namespace std;

typedef struct node *p_node;
typedef struct node
{
    p_node left;
    char name[20];
    int num;
    p_node link;
};

int main()
{

    int counte=0;
    int counte1=0;
    node* x,*y,*temp;
    int i,n;
    char s[20];
    cout << "Tedad NODE hara vared konid : ";
    cin >> n;
    //Create the list
    x =new node;
    cout<< endl<<"NODE -> 1"<<endl;
    cout <<"Name : ";
    cin>>x->name;
    cout <<"Number : ";
    cin>>x->num;
    x->link=NULL;
    x->left=NULL;
    temp = x;
    for(i=2;i<=n;i++)
    {
        cout<< endl <<"NODE -> "<<i<<endl;
        y=new node;
        cout <<"Name : ";
        cin>>y->name;
        cout <<"Number : ";
        cin>>y->num;
        y->link=NULL;
        temp->link=y;
        y->left=temp;
        temp=temp->link;
    }
    cout<< endl;

    for(int y=0;y>=-1;y++)
    {
        int s;
        cout<<"1 -> Search"<<endl;
        cout<<"2 -> Show"<<endl;
        cout<<"3 -> Exit"<<endl<<endl;
        cout << "Enter number : ";
        cin>>s;
        cout<<endl;
        if(s==3) break;
        switch (s)
        {
            case 1:
                int a;
                cout << "1 -> Search Name"<<endl;
                cout << "2 -> Search Number"<<endl<<endl;
                cout << "Enter Number : ";
                cin >>a;
                cout<<endl;
                switch (a)
                {
                case 1:
                    char name1[20];
                    cout<<"Enter search value : ";
                    cin>>name1;
                    cout << endl;
                    temp=x;
                    int result;
                    while(temp!=NULL)
                        {
                            result=strcmp(temp->name,name1);
                            if(result==0)
                            {
                                temp=temp->left;
                                cout << temp->name << "\t" << temp->num<<endl;
                                temp=temp->link;
                                counte++;
                            }
                            temp = temp->link;
                        }
                            if(counte==0)
                            {
                                cout<<"Hich dadei yaft nashod."<<endl;
                            }
                             counte=0;
                    cout<<endl;
                    break;
                case 2:
                    int num1;
                    cout<<"Enter search value : ";
                    cin>>num1;
                    cout << endl;
                    temp=x;

                    while(temp!=NULL)
                        {
                            if(temp->num==num1)
                            {
                                cout << temp->name << "\t" << temp->num<<endl;
                                counte1++;
                            }
                            temp = temp->link;
                        }
                                  if(counte1==0)
                            {
                                cout<<"Hich dadei yaft nashod."<<endl;
                            }
                            counte1=0;
                        cout<<endl;
                    break;
                default:
                    cout << "Error : Amaliyat eshtebah";
                    break;
                }
                break;
            case 2:
                temp=x;
                cout<< "Names"<<"\t"<<"Numbers"<<endl<<endl;
                while(temp!=NULL)
                {
                    cout<<temp->name<< "\t" << temp->num <<endl;
                    temp = temp->link;
                }
                cout << endl;
                break;
            default:
                cout << "Error : Amaliyat eshtebah";
                break;
        }
        }


    return 0;
}
