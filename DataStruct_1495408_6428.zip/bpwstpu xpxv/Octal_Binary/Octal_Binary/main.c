#include <stdio.h>
#include <stdlib.h>
void binarys2(int x)
{
    int kharej;
    int bagi[55];
    int shart = 1;
    int z = 0;
    while(shart == 1)
    {
        //for(int z = 0; z < 55; z++)
        //{
            kharej = x / 2;
            bagi[z] = x % 2;
            if((kharej <2))
            {
                printf("Binary: %d",kharej);
                for(int y = z; y >=0; y--)
                {
                    printf("%d",bagi[y]);
                }
                //z = 56;
                shart =0;
            }
            x = kharej;
        //}
        z += 1;
    }
}
void octals2(int x)
{
    int kharej;
    int bagi[55];
    int shart = 1;
    int z = 0;
    while(shart == 1)
    {
        //for(int z = 0; z < 55; z++)
        //{
            kharej = x / 8;
            bagi[z] = x % 8;
            if((kharej <8))
            {
                printf("Octal: %d",kharej);
                for(int y = z; y >=0; y--)
                {
                    printf("%d",bagi[y]);
                }
                //z = 56;
                shart =0;
            }
            x = kharej;
        //}
        z += 1;
    }
}
int main()
{
    int binarys[55];
    int octals[55];

    printf("Adade morede ra vared konid\n");
    int adad = 0;
    scanf("%d",&adad);
    //printf("%d  %d", 6 /2,6 % 2);
    binarys2(adad);
    printf("\n");
    octals2(adad);
    return 0;
}
