﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Touraj
{
    class Program
    {
        static void Main(string[] args)
        {
            int boolCon = 1;
            do
            {
                string[] Stack = new string[30];
                int top = -1;
                string Reshte;
                int options = 0;
                System.Console.Clear();
                Console.WriteLine("1. PostFix to PreFix  2. PreFix to PostFix  3. Exit \n");
                options = int.Parse(Console.ReadLine().ToString());
                switch(options)
                {
                    case 1:
                Console.WriteLine("PostFix Vared Konid");
                Reshte = Console.ReadLine();
                string temp = "";
                for (int x = 0; x < Reshte.Length; x++)
                {
                    if ((Reshte[x] >= 65 && Reshte[x] <= 90) || (Reshte[x] >= 97 && Reshte[x] <= 122))
                    {
                        Stack[++top] = Reshte[x].ToString();
                    }
                    else
                    {
                        temp = Stack[top - 1] = Reshte[x] + Stack[top - 1] + Stack[top];
                        top -= 1;
                    }
                }
                Console.WriteLine("Prefix hast:");
                Console.Write("{0}", temp);
                Console.ReadKey();
                break;

                    case 2:
                Console.WriteLine("PreFix Vared Konid");
                Reshte = Console.ReadLine();
                string temp2 = "";
                for (int x = Reshte.Length-1; x >= 0; x--)
                {
                    if ((Reshte[x] >= 65 && Reshte[x] <= 90) || (Reshte[x] >= 97 && Reshte[x] <= 122))
                    {
                        Stack[++top] = Reshte[x].ToString();
                    }
                    else
                    {
                        temp2 = Stack[top - 1] = Stack[top] + Stack[top - 1] + Reshte[x];
                        //temp2 = Stack[top - 1] = Reshte[x] + Stack[top - 1] + Stack[top];
                        top -= 1;
                    }
                }
                Console.WriteLine("PostFix hast:");
                Console.Write("{0}", temp2);
                Console.ReadKey();
                break;

                    case 3:
                Console.Write("Have Good time. Touraj Ostovari. Touraj.Ostovari@gmail.com");
                Console.ReadKey();
                boolCon = 0;
                break;
                    default:
                Console.Write("Have Good time. Touraj Ostovari. Touraj.Ostovari@gmail.com");
                Console.ReadKey();
                boolCon = 0;
                break;
                }
            } while (boolCon == 1);
        }
    }
}
