#include <stdio.h>
#include <stdlib.h>

int main()
{
    int fronts=0, index=0;
    int n;
    puts("Tool array vared konid");
    scanf("%d",&n);
    int Saff[n];
    int ShartExit = 0;
    do
    {
        int options=0;
        system("cls");
        puts(" 1. Add   2. Delete  3. Show FIFO   4. Exit");
        scanf("%d",&options);
        switch(options)
        {
        case 1:
            if(index < n){
            puts("Adad vared konid");
            scanf("%d",&Saff[index]);
            index += 1;
            }
            else
            {
                puts("Saff poor shode hast");
                int x = 0;
            scanf("%d",&x);
            }

            break;
        case 2:
            if(fronts < index){
            printf("\n%d\n",Saff[fronts]);
            Saff[fronts] = -1;
            fronts += 1;
            getchar();
            }
            else
            {
                printf("Nemishe Delete kard bish az hade megdar vorodi");
            }
            break;
        case 3:
            if (fronts < index){
            printf("\n%d\n",Saff[fronts]);
            int x = 0;
            scanf("%d",&x);
            }
            else if (fronts == index)
                printf("Nemishe FIFO bish az megdar neshan dad");
            break;
        case 4:
            return 0;
            break;
        default:
            return 0;
            break;
        }
    } while(ShartExit == 0);
}
