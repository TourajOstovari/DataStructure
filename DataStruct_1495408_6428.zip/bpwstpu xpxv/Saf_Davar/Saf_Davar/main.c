#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n = 0;
    puts("Tool array vared konid");
    scanf("%d",&n);
    int arrays[n];
    int front = 0, rear = 0;
    do
    {
        int options = 0;
        system("cls");
        puts("1. Add  2. Delete  3. Exit");
        scanf("%d",&options);
        switch(options)
        {
        case 1:
            if(front != ((rear + 1) % n)){
                if(rear < n -1){
                rear += 1;
                scanf("%d",&arrays[rear]);
                getchar();
                }
                else if(rear == n -1)
                {
                    rear = 0;
                    scanf("%d",&arrays[rear]);
                }
            }
            else
            {
                puts("Saff davvar poor shode hast");
                getchar();
            }
            break;
        case 2:
            if( front != rear)
            {
                if(front < n)
                {
                    front += 1;
                    printf("%d",arrays[front]);
                    arrays[front] = 0;
                }
                else if(front == n)
                {
                    front = 0;
                    printf("%d",arrays[front]);
                    arrays[front] = 0;
                }
            }
            else
            {
                puts("Saff davvar khali hast");
                getchar();
            }
            break;
        case 3:
            return 0;
            break;
        default:
            return 0;
            break;
        }
    }while(1);

}
