﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Search_Hobabi
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            Console.WriteLine("Tedad vorodi vared konid");
            n=int.Parse(Console.ReadLine());
            int[] values = new int[n];
            Console.Clear();
            for(int x=0; x < n; x++)
            {
                Console.WriteLine("Adade " + x +" vared konid");
                values[x] = int.Parse(Console.ReadLine());
            }
            for (int i = n; i >= 0;i--)
            {
                for(int j=0;j<i-1;j++)
                {
                    if(values[j] > values[j+1])
                    {
                        int temp = values[j + 1];
                        values[j + 1] = values[j];
                        values[j] = temp;
                    }
                }
            }
            Console.Clear();
            Console.WriteLine("Adade hasele baad az moratab sazi:");
            for (int x = 0; x < n; x++)
            {
                Console.WriteLine("Adad hasele:" + values[x]);
                
            }

                Console.ReadKey();
        }
    }
}
