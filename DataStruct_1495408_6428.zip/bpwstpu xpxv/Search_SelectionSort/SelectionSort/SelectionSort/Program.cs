﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace SelectionSort
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            Console.WriteLine("Tool array ra vared konid");
            n = int.Parse(Console.ReadLine());
            int[] arrays = new int[n];
            int nValue = n; // ino tarif kardam chon akhar sar lazem mishe too chaap moratab shode
            Console.WriteLine("\nMegdar haro vared konid");
            for (int x = 0; x < n; x++)
                arrays[x] = int.Parse(Console.ReadLine().ToString());

            do
            {
            int temp = 0;
            int GreatValue = 0; 
            int GreatIndex = 0;
            bool Conditions = false;
            int x = 0;
                for (;x <= n-1; x++)
                {
                    if (GreatValue < arrays[x])
                    {
                        GreatValue = arrays[x];
                        GreatIndex = x;
                        Conditions = true;
                    }
                }
                if(Conditions == true)
                {
                    temp = arrays[n - 1];
                    arrays[n - 1] = GreatValue;
                    arrays[GreatIndex] = temp;
                    Conditions = false;
                }
                x = 0;
                n -= 1;
            } while (n != 0);
            Console.Write("\nResult:\n");
            for (int z = 0; z < nValue; z++ )
            {
                Console.Write(arrays[z].ToString() + '\t');
            }
            Console.ReadLine();
        }
    }
}