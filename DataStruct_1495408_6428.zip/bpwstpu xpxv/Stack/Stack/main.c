#include <stdio.h>
#include <stdlib.h>

int lengthArray=0;
int arrayIndex=0;
int main()
{
    int whiles=0;
    puts("please enter stack array length");
        scanf("%d",&lengthArray);
        int stackarray[lengthArray];

    while (whiles == 0)
    {
        system("cls");
        int item=0;
        printf("please choose one the items\n");
        puts("1. Push  2. Pop  3. Show last value  4. Exit");
        scanf("%d",&item);
        switch(item)
        {
        case 1:
            puts("enter your value to set");
            int valuex=0;
          scanf("%d",&valuex);
        pushs(&stackarray,valuex);
        break;
        case 2:
        pops(&stackarray);
        break;
        case 3:
        tops(&stackarray);
        break;
        case 4:
        whiles = 1;
        break;
        default:
        return 1;
        }
    }

    return 0;
}
int x=0;
void pushs(int *pStack,int values)
{
    if (arrayIndex < lengthArray) {
    pStack[arrayIndex]= values;
    arrayIndex += 1;
    scanf("%d",&x);
    }
    else {
        printf("Array is out range, you can not add more values in this stack");
        scanf("%d",&x);
    }

}
void pops(int *pStack)
{
    if (arrayIndex > 0 ) {
    pStack[arrayIndex]= 0;
    arrayIndex -= 1;
    }
    else {
        printf("Array is under range, you can not sub more values in this stack");
        scanf("%d",&x);
    }
}
int tops(int *pStack)
{
    if(arrayIndex-1 >= 0)
    {
      printf("Top value is: %d\n",pStack[arrayIndex-1]);
    scanf("%d",&x);
    }
    else{
        printf("moredi add nashode\n");
        scanf("%d",&x);
    }

}
