#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Salam\n");
    puts("Tedade row haro vared konid");
    int row1=0,columns1=0;
    scanf("%d",&row1);
    puts("\nTedade columns haro vared konid");
    scanf("%d",&columns1);
    int A[row1][columns1];
    int a[columns1][row1];
    for(int x=0;x<row1;x++)
    {
        for(int y=0;y<columns1;y++)
        {
            printf("A[%d][%d]=",x,y);
            scanf("%d",&A[x][y]);
            a[y][x] = A[x][y];
        }
    }
    printf("Asli \n");
    for(int x=0;x<row1;x++)
    {
        for(int y=0;y<columns1;y++)
        {
            printf("%d\t",A[x][y]);
        }
        printf("\n");
    }

    printf("\nTaranahade Shode \n");

    for(int x=0;x<columns1;x++)
    {
        for(int y=0;y<row1;y++)
        {
            printf("%d\t",a[x][y]);
        }
        printf("\n");
    }



    return 0;
}
