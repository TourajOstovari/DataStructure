#include <stdio.h>
#include <stdlib.h>

int main()
{
    puts("Adad mored nazar vared konid");
    int n = 0;
    scanf("%d",&n);
    printf("\n result: %d",fact(n));
    return 0;
}
int fact(int n)
{
    if(n == 1)
    {
        return 1;
    }
    else
    {
        return n * fact(n-1);
    }
}
