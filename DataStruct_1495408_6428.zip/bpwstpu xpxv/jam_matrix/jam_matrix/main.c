#include <stdio.h>
#include <stdlib.h>

int main()
{
    int satrs,sotons;
    printf("Salam, lotfan tedade satr va sotone matrix A B vared konid:\n");

    puts("Satr ha");
    scanf("%d",&satrs);

    puts("Soton ha");
    scanf("%d", &sotons);

    int A[satrs][sotons];
    int B[satrs][sotons];
    int Sums[satrs][sotons];

    puts("magadire matrix A vared konid");
    printf("example: 2\n");
    for(int x=0;x< satrs; x++)
    {
        for(int y=0; y < sotons; y++)
        {
            scanf("%d",&A[x][y]);
        }
    }

    puts("\nmagadire matrix B vared konid");
    printf("example: 2\n");
    for(int x=0;x< satrs; x++)
    {
        for(int y=0; y < sotons; y++)
        {
            scanf("%d",&B[x][y]);
            Sums[x][y] = A[x][y] + B[x][y];
        }
    }
    printf("\n");
    for(int x=0; x< satrs; x++)
    {
        for(int y=0; y < sotons; y++)
        {
            printf("%d\t",Sums[x][y]);
        }
        printf("\n");
    }
    return 0;
}
