#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    int exits = 0;
    while(exits == 0)
    {
    system("cls");
    puts("Lotfan har yak az zarib hay x ke a b c hastand vared konid:");

    int a;
    puts("a ra vared konid");
    scanf("%d", &a);

    int b;
    printf("\nb ra vared konid \n");
    scanf("%d",&b);

    int c;
    printf("\nc ra vared konid \n");
    scanf("%d",&c);

    float results = ((b * b)) - ((4 * a * c));
    printf("\n%.3f delta hast\n", results);
    if  (results < 0 )
    {
        printf("\nRishe Hagigi nadarad\n");
    }
    if (results == 0)
    {
        printf("\nRishe Mozaaf darad\n");
        printf("-b / 2a = %d",(-b / (2 * a)));
    }
    if  (results > 0)
    {
        printf("\nDaray 2 rishe hast\n");
        printf("%.3f\n",((-b) - sqrt(results)) / (2 * a) );
        printf("%.3f\n",((-b) + sqrt(results)) / (2 * a) );

    }

    puts("mikhayn ke barname khateme peyda kone ya kheyr?? Baraye Khoroj 1 va baraye edame 0");
    scanf("%d",&exits);
    if (exits > 0)
    {
    system("cls");
    return 0;
    }

    }

}
