#include<iostream>
#include<conio.h>
using namespace std;

void read(int [][100],int,int);
void print(int [][100],int,int);
void multi(int[][100],int[][100],int[][100],int,int,int);
int i,j;

main()
{
int a[100][100],b[100][100],c[100][100];
int k,m,n,p;
char ch;
cout<<"matrix A row=";
cin>>m;
cout<<"\n"<<"matrix A column=";
cin>>n;
cout<<"\n"<<"matrix B column=";
cin>>p;
system("cls");
cout<<"Enter matrix A:\n\n";
read(a,m,n);
system("cls");
cout<<"Enter matrix B:\n\n";
read(b,n,p);
multi(a,b,c,m,n,p);
system("cls");
cout<<"A*B:\n\n";
print(c,m,p);
cout<<"\n\n\n"<<"exit...?(y/n):";
cin>>ch;
if(ch=='y'||ch=='Y')
return 0;
else
main();
}

//***********
void read(int a[][100],int m,int n)
{
for(i=0;i<m;i++)
{
for(j=0;j<n;j++)
{
cout<<"["<<i<<','<<j<<"]=";
cin>>a[i][j];
}
}//end of for
}//end of read()

//**********
void print(int a[][100],int m,int n)
{
for(i=0;i<m;i++)
{
for(j=0;j<n;j++)
cout<<a[i][j]<<"\t";
cout<<"\n";
}
}//end of print()

//**********
void multi(int a[][100],int b[][100],int c[][100],int m,int n,int p)
{
for(i=0;i<m;i++)
{
for(j=0;j<p;j++)
{
c[i][j]=0;
for(int k=0;k<n;k++)
c[i][j]+=a[i][k]*b[k][j];
}
}//end of for
}//end of multi()

